import React, { useState } from "react";
import "../style.css";

const Todos = () => {
  const [data, setData] = useState([]);
  const [input, setInput] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault(); // stop page reload

    if (input.trim() === "") return; // ignore empty todos

    setData((prevData) => [
      ...prevData,
      {
        text: input,
        id: Math.floor(Math.random() * 10000),
      },
    ]);

    setInput(""); // clear input
  };

  return (
    <div>
      <ul className="todos-list">
        {data.map(({ id, text }) => (
          <li className="todo" key={id}>
            <span>{text}</span> <button className="close" onClick={() => setData(data.filter(todo => todo.id !== id))}>X</button>
          </li>
          
        ))}
      </ul>

      <form onSubmit={handleSubmit}>
        <div className="container">
          <input
            type="text"
            placeholder="Enter Todo List"
            value={input}
            onChange={(e) => setInput(e.target.value)}
          />

          <button type="submit">Submit</button>
        </div>
      </form>
    </div>
  );
};

export default Todos;
