import React from "react";
import { useState } from "react";
import "../styles/ToggleColor.css";

const ToggleBackgroundColor = () => {
  const [background, setBackground] = useState("white");
  const [textcolor, setTextcolor] = useState("#1b1b1b");
  const [buttonstyle, setButtonstyle] = useState("white");

  const handleClick = () => {
    setBackground(background === "white" ? "#1b1b1b" : "white");
    setTextcolor(textcolor === "#1b1b1b" ? "#ffa31a" : "#1b1b1b");
    setButtonstyle(buttonstyle === "white" ? "#1b1b1b" : "white");
  };

  return (
    <div style={{ background, color: textcolor }}>
      <button style={{ buttonstyle, color: textcolor, border: `2px solid ${textcolor}` }} onClick={handleClick}>
        {  background === "white" ? "DARK MODE" : "LIGHT MODE"}
      </button>
      <section className="content">
        <h1>
          WELCOME TO THE <br />
          . . DARK SIDE . . .
        </h1>
      </section>
    </div>
  );
};

export default ToggleBackgroundColor;
