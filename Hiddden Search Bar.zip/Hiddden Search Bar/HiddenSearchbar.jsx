import React from "react";
import { useState } from "react";
import "../styles/HiddenSearchbar.css";
import { FaSearch } from "react-icons/fa";

const HiddenSearchbar = () => {
  const [showinput, setShowinput] = useState(false);
  const [background, setBackground] = useState("white");

  const handleClick = (e) => {
    setBackground("#1a1a1a");

    if (e.target.className === "content") {
      setShowinput(false);
      setBackground("white");
    }
  };

  return (
    <section
      className="content"
      style={{ backgroundColor: background }}
      onClick={handleClick}
    >
      {showinput ? (
        <input type="text" placeholder="Search ..." />
      ) : (
        <FaSearch onClick={() => setShowinput(true)} />
      )}
    </section>
  );
};

export default HiddenSearchbar;
